<!DOCTYPE html>
<html>
<head>
	<title>Gracias por su compra</title>
</head>
<body>
	<h1>Gracias por su compra</h1>
	<h2>Detalles de la Transaccion</h2>
	<p>ID de compra: </p>
	<p>Valor: </p>
	<p>Nro de cuotas: </p>
	<p>Fecha de transaccion: </p>
	<p>Estado Completada</p>
	<button>Regresar a Transfer</button>
</body>
</html>