<!DOCTYPE html>
<html>
<head>
	<title>Transfer Result</title>
</head>
<body>
	<?php
		/*$result = $transaction->getTransactionResult($request->input("token_ws"));
		$output = $result->detailOutput;
		if ($output->responseCode == 0) {
		    echo '<label>Exitoso</label>';
		}else{
			echo '<label>No exitoso</label>';
		}*/
	?>
</body>
</html>