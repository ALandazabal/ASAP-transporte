<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-md-8 col-md-offset-2" id="formContact">
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<!-- Inicialización de variables de precios -->
		<?php
			$totalpax = 0;
			$totalg = 0;
		?>

		<div class="panel panel-default">
			<div class="panel-heading" id="formContactTitle">
				<h3 class="panel-title">Información de solicitud</h3>
			</div>
			<div class="panel-body">					
				<div class="table-container">
					<form method="post" action="<?php echo e(route('transfer.store')); ?>"  role="form">
						<?php echo e(csrf_field()); ?>

						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<label for="name">Nombre: </label><label class="dataTransfer"><?php echo e(Auth::user()->name); ?></label>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label for="email">Correo Electrónico: </label><label class="dataTransfer"><?php echo e(Auth::user()->email); ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<label for="name">Tipo de viaje: </label><label class="dataTransfer"><?php echo e($tviaj->descripcion); ?></label>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label for="email">Fecha y hora: </label><label class="dataTransfer"><?php echo date("d/m/Y", strtotime($form_data['date']))?>  <?php echo e($form_data['time']); ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<label for="name">Desde: </label><label class="dataTransfer"><?php echo e($origen->name); ?></label>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label for="email">Hasta: </label><label class="dataTransfer"><?php echo e($destino->name); ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							
							<div class="col-xs-6">
								<div class="form-group">
									<label for="name">Descripción: </label><label class="dataTransfer"><?php echo e($preciod->descripcion); ?></label>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label for="suitcase">Cantidad de maletas: </label><label class="dataTransfer"><?php echo e($form_data['suitcase']); ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6 col-xs-push-6">
								<div class="form-group">
									<label for="email">Precio: </label><label class="dataTransfer"><?php echo e($preciod->precio); ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<label for="passenger">Cantidad de pasajeros: </label><label class="dataTransfer"><?php echo e($form_data['passenger']); ?></label>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label for="email">Precio: </label><label class="dataTransfer"><?php echo e($cuotaPax); ?></label>
									<?php $totalpass = $cuotaPax; ?>
								</div>
							</div>
						</div>
				
				<?php if(isset($form_data['sguia'])): ?>
					<?php $__currentLoopData = $servs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($serv->id == 2): ?>
						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<label for="name">Servicio: </label><label class="dataTransfer"><?php echo e($serv->descripcion); ?></label>
										
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label for="email">Precio: </label><label class="dataTransfer"><?php echo e($serv->price); ?></label>
									<?php $totalg = $serv->price; ?>
								</div>
							</div>
						</div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
						<div class="row">
							<div class="col-xs-6 col-xs-offset-6">
								<div class="form-group">
									<label for="email">Total: </label><label class="dataTransfer">
										<?php 
											$total = $preciod->precio + $totalg + $totalpass;
											echo $total;
										?>											
									</label>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<div class="col-md-12">
										<label for="pago">Método de Pago</label>
									</div>
									<div class="col-md-6">
										<input type="radio" class="" name="pago" value="webpay"> WebPay+
									</div>						
														
								</div>
							</div>
						</div>

						
						<input type="hidden" name="name" value="<?php echo e($form_data['name']); ?>">
						<input type="hidden" name="email" value="<?php echo e($form_data['email']); ?>">
						<input type="hidden" name="origin" value="<?php echo e($form_data['origin2']); ?>">
						<input type="hidden" name="comuna" value="<?php echo e($form_data['comunat']); ?>">
						<input type="hidden" name="tviaje" value="<?php echo e($form_data['tviajet']); ?>">
						<input type="hidden" name="date" value="<?php echo e($form_data['date']); ?>">
						<input type="hidden" name="time" value="<?php echo e($form_data['time']); ?>">
						<input type="hidden" name="vehicle" value="<?php echo e($form_data['vehicle']); ?>">
						<input type="hidden" name="passenger" value="<?php echo e($form_data['passenger']); ?>">
						<input type="hidden" name="suitcase" value="<?php echo e($form_data['suitcase']); ?>">
						<?php 
							if(isset($form_data['sguia'])){
						?>
								<input type="hidden" name="sguia" value="1">
						<?php
							}else{
						?>
								<input type="hidden" name="sguia" value="0">
						<?php
							}
						?>
						

						<div class="row buttonSend">
							<div class="col-xs-12">
								<a href="<?php echo e(route('transfer.create')); ?>" class="btn btn-info" >Atrás</a>
								<button class="btn btn-success" type="submit">Solicitar</button>
							</div>	
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>