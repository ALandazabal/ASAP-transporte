<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="col-md-4 col-md-offset-4 text-center">
		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Error!</strong> Revise los campos obligatorios.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">Edita Transfer/Tour</h3>
			</div>
			<div class="panel-body">
				<div class="table-container">
					<form method="post" action="<?php echo e(route('precios.update', $precios->id)); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<input name="_method" type="hidden" value="PATCH">
						<label for="tposviajei">Tipo de viaje</label>
						<select class="form-control" name="tposviajei">
							
							<?php $__currentLoopData = $tviajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tviaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if( $tviaje->id == $precios->tviaje->id ): ?>
									<option value="<?php echo e($tviaje->id); ?>" selected="selected"><?php echo e($tviaje->descripcion); ?></option>
								<?php else: ?>
									<option value="<?php echo e($tviaje->id); ?>"><?php echo e($tviaje->descripcion); ?></option>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<label for="Comuna">Comuna</label>
						<select class="form-control" name="comuna">
							
							<?php $__currentLoopData = $comunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if( $comuna == $precios->comuna ): ?>
									<option value="<?php echo e($comuna->id); ?>" selected="selected"><?php echo e($comuna->name); ?></option>
								<?php else: ?>
									<option value="<?php echo e($comuna->id); ?>"><?php echo e($comuna->name); ?></option>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<label for="Description">Descripción</label>
						<input type="text" class="form-control" name="description" value="<?php echo e($precios->descripcion); ?>">					
						<label for="Price">Precio</label>
						<input type="text" class="form-control" name="precio" value="<?php echo e($precios->precio); ?>">
						<button type="submit" class="btn btn-success">Guardar</button>
						<a href="<?php echo e(route('precios.index')); ?>" class="btn btn-info" >Atrás</a>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>