<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-md-5 col-md-offset-4" id="formEnvio">
		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Error!</strong> Revise los campos obligatorios.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<div class="panel panel-default">
			<div class="panel-heading" id="formTitle">
				<h3 class="panel-title">Solicitud</h3>
			</div>
			<div class="panel-body">					
				<div class="table-container">
					<form method="post" action="<?php echo e(route('transfer.contact')); ?>" role="form">
						<?php echo e(csrf_field()); ?>

						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="name">Nombre</label>
									<input type="text" class="form-control input-sm" name="name2" value="<?php echo e(Auth::user()->name); ?>" required disabled>
									<input type="hidden" class="form-control input-sm" name="name" value="<?php echo e(Auth::user()->name); ?>" required >
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="email">Correo Electrónico</label>
									<input type="email" class="form-control input-sm" name="email2" value="<?php echo e(Auth::user()->email); ?>" required disabled>
									<input type="hidden" class="form-control input-sm" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="Tviajet">Tipo de servicio:</label>
									<select class="form-control" name="tviajet" id="tviajet">
										<option selected="selected">Seleccione un tipo de servicio</option>
										<?php $__currentLoopData = $tposviaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tviaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($tviaje->id); ?>"><?php echo e($tviaje->descripcion); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="Origin2">Origen:</label>
									<select class="form-control" name="origin2" id="origin2">
										
									</select>
									<input type="hidden" class="form-control input-sm" name="origin" value="Aeropuerto Internacional Comodoro Arturo Medino Benítez" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="Comunat">Destino:</label>
									<select class="form-control" name="comunat" id="comunat">
										
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="passenger">Número de pasajeros:</label>
									<select class="form-control" name="passenger" id="passenger">
										<option selected="selected">Seleccione una cantidad</option>
										<?php $__currentLoopData = $passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($passenger->id); ?>"><?php echo e($passenger->descripcion); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label for="Date">Fecha de Búsqueda</label>
									<input type="date" class="form-control" name="date" required min="<?php $hoy=date('Y-m-d'); echo $hoy; ?>">
									<label for="Time">Hora de Búsqueda</label>
									<input type="time" class="form-control" name="time" required>
								</div>
							</div>
						</div>
						
						<input type="hidden" name="vehicle" value="<?php echo e($vehicles->id); ?>">
						
						<div class="row">
							<div class="col-xs-8">
								<div class="form-group">
									<label for="suitcase">Número de maletas:</label>
									<input type="number" name="suitcase" id="suitcase" min="0" max="99" value="0">
								</div>
							</div>
						</div>
						<!-- <div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<label><input type="checkbox" id="travelType" value="Tipo de viaje"> Ida y vuelta</label><br>
								</div>
							</div>
						</div> -->
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<input type="checkbox" name="sguia" id="sguia" value="2"> <label>Servicio guía de idioma</label><br>
								</div>
							</div>
						</div>
						<div class="row text-center">
							<div class="col-xs-12">							
								<button class="btn btn-success" type="submit">Solicitar</button>
							</div>	
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>