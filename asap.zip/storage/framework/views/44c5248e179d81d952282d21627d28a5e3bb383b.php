<?php $__env->startSection('content'); ?>
<div class="row">
	<section class="filters">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<h3>Busqueda por:</h3>
			</div>
		</div>
		<div class="col-md-8 col-md-offset-2">
			<form method="GET" action="<?php echo e(action('TransferController@indexu', Auth::user()->id)); ?>"  role="form">
				<?php echo e(csrf_field()); ?>

				
				<div class="col-xs-4">
					<div class="form-group">
						<input type="text" name="destinob" id="destinob" class="form-control input-sm" placeholder="Destino">
					</div>
				</div>
				<div class="col-xs-4">
					<div class="form-group">
						<input type="date" name="finicial" id="finicial" class="form-control input-sm" >
					</div>
				</div>
				<div class="row">
					<div class="col-md-10 col-md-offset-2 text-right">
						<button class="btn btn-success" type="submit">Buscar</button>
					</div>	
				</div>
			</form>
		</div>
	</section>
	<section class="content">
		<div class="col-md-8 col-md-offset-2">
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="pull-left"><h3>Lista Transfers</h3></div>
					<div class="table-container">
						<table id="mytable" class="table table-bordred table-striped">
							<thead>
								<th>#</th>
								<th>Login</th>
								<th>Vehículo</th>
								<th>Destino</th>
								
								<th>Detalle</th>
							</thead>
							<tbody>
								<?php if($transfers != null): ?>
								<?php if($transfers->isNotEmpty()): ?>
									<?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
										<tr>
											<th><?php echo e($transfer->id); ?></th>
											<td><?php echo e($transfer->email); ?></td>
											<td><?php echo e($transfer->vehicle->description); ?></td>
											<?php if($precios->isNotEmpty()): ?>
												<?php $__currentLoopData = $precios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($precio->id == $transfer->precio_id): ?>
														<?php if($comunas->isNotEmpty()): ?>
															<?php $__currentLoopData = $comunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<?php if($comuna->id == $precio->comuna_id): ?>
																	<td><?php echo e($comuna->name); ?></td>
																<?php endif; ?>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
														<?php else: ?>
															<tr>
																<td colspan="8">No hay registros !!</td>
															</tr>
														<?php endif; ?>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
											<?php else: ?>
												<tr>
													<td colspan="8">No hay registros !!</td>
												</tr>
											<?php endif; ?>
											
											<td><a class="btn btn-primary btn-xs" href="<?php echo e(action('TransferController@edit', Crypt::encrypt($transfer->id))); ?>" ><span class="glyphicon glyphicon-pencil"></span></a>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
								<?php else: ?>
								<tr>
									<td colspan="8">No hay registros !!</td>
								</tr>
								<?php endif; ?>
								<?php else: ?>
								<tr>
									<td colspan="8">No hay registros !!</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>