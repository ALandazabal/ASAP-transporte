<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Dashboard</div>

                    <div class="panel-body" id="dashboard">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if( Auth::user()->isAdmin()): ?>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Usuarios</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina los usuarios que tendrán acceso a la página.<br>
                                        <center>
                                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Lugares</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina comunas o los lugares turísticos.<br>
                                        <center>
                                        <a href="<?php echo e(route('comuna.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Vehículos</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina vehículos para la disponibilidad del sistema.<br>
                                        <center>
                                        <a href="<?php echo e(route('vehicle.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Transfers</h5>
                                    </div>
                                    <div class="panel-body">
                                        Visualizar o modificar las Transfers solicitadas por los usuarios.<br>
                                        <center>
                                        <a href="<?php echo e(route('transfer.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Slider</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina items para mostrar en el slider de la página principal.<br>
                                        <center>
                                        <a href="<?php echo e(route('sliderconfig.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Precios Transfers/Tours</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina los precios de cada servicio ofertado.<br>
                                        <center>
                                        <a href="<?php echo e(route('precios.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar servicios adicionales</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina los servicios adicionales ofertados.<br>
                                        <center>
                                        <a href="<?php echo e(route('service.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Pasajeros</h5>
                                    </div>
                                    <div class="panel-body">
                                        Añade, modifica, elimina los precios por pasajero en traslados.<br>
                                        <center>
                                        <a href="<?php echo e(route('passenger.index')); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Perfil</h5>
                                    </div>
                                    <div class="panel-body">
                                        Visualiza o modifica tus datos.<br>
                                        <center>
                                        <a href="<?php echo e(action('UsersController@edit', Auth::user()->id)); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h5 class="panel-title">Administrar Transfers</h5>
                                    </div>
                                    <div class="panel-body">
                                        Visualiza o modifica las Transfers solicitadas por ti.<br>
                                        <center>
                                        <a href="<?php echo e(action('TransferController@indexu', Auth::user()->id)); ?>" class="btn btn-default">Ir!</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>