<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title><?php echo $__env->yieldContent('pageTitle'); ?>ASAP Servicio de Transporte</title>
	<link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
	<header>
		<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</header>
	<section class="container" id="container">
		<?php echo $__env->yieldContent('content'); ?>
	</section>
	<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script> -->
	<script type="text/javascript" src="<?php echo e(asset('js/events.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>