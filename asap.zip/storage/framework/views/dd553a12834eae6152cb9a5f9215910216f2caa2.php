<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="col-md-4 col-md-push-4 text-center">
		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Error!</strong> Revise los campos obligatorios.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">Nuevo Vehículo</h3>
			</div>
			<div class="panel-body">
				<div class="table-container">
					<form method="post" action="<?php echo e(route('vehicle.store')); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<label for="Description">Descripción</label>
						<input type="text" class="form-control" name="description" required>
						<label for="Passengers">Pasajeros</label>
						<input type="number" max="100" min="0" class="form-control" name="passengers" required>
						<label for="Photo">Imagen</label>
						<input type="file"  name="photo">
						<button type="submit" class="btn btn-success">Agregar</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>