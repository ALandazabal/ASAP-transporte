<?php $__env->startSection('styles'); ?>
<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="<?php echo e(asset('owlcarousel/assets/owl.carousel.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('owlcarousel/owl.carousel.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid cont-1 text-center ext cont-light-grey">
	<h2>Bienvenido a ASAP</h2>
	<div class="col-md-6">
		<h2><i class="fas fa-map-marked-alt"></i></h2>
		<h3>Turismo</h3>
		<span>Ofrecemos servicios de transporte turistico a cualquier lugar de Chile, para que usted pueda obtener un viaje placentero hacia su empresa o lugar de destino..</span>
	</div>
	<div class="col-md-6">
		<h2><i class="fas fa-shuttle-van"></i></h2>
		<h3>Servicio de Transfer</h3>
		<span>Ofrecemos servicios de transporte para su empresa, organización o institución, con la seguridad de una empresa de trayectoria, compuesta por profesionales expertos en transporte.</span>
	</div>
</div>
<div class="container-fluid  text-center cont-2 ext">
	<h2>Vehiculos Disponibles</h2>
	<div class="">
		<script type="text/javascript">
			$(document).ready(function() {
				$('.owl-cars').owlCarousel({
					autoplay: true,
				    autoplayHoverPause: true,
				    margin:10,
					loop: true,
				    responsiveClass:true,
					items:1
				});
			});
		</script>
		<div class="owl-cars owl-carousel owl-theme">
			<?php if($slider->isNotEmpty()): ?>
			<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="item">
				<div class="test">
					<img src="../img/carimages/<?php echo e($slide->photo); ?>">
					<div class="etiquetaImg">
						<h3><?php echo e($slide->title); ?></h3>
						<span class="quote"><?php echo e($slide->description); ?></span>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="container-fluid text-center cont-3 ext">
	<div class="col-md-6 container-fluid text-center cont-dark-grey icons cont-box3">
		<h3 id="iconValores">Nuestros valores</h3>
		<div class="col-md-6">
			<i class="fas fa-car-side"></i>
			<h4>Discresion</h4>
		</div>
		<div class="col-md-6">
			<i class="fas fa-truck-pickup"></i>
			<h4>Comodidad</h4>
		</div>
		<div class="col-md-6">
			<i class="fas fa-helicopter"></i>
			<h4>Puntualidad</h4>
		</div>
		<div class="col-md-6">
			<i class="fas fa-shuttle-van"></i>
			<h4>Atencion 24/7</h4>
		</div>
	</div>
	<div id="prueba" class="col-md-6 container-fluid text-center cont-light-blue cont-box3">
		<div class="jumbotron">
			<h2>Cotizacion</h2>
			<form method="post" action="<?php echo e(route('contizacionForm')); ?>"  role="form">
				<?php echo e(csrf_field()); ?>

				<!-- <?php if(Session::has('success')): ?>
				<div class="alert alert-info">
					<?php echo e(Session::get('success')); ?>

				</div>
				<?php endif; ?> -->
				<?php
					if(isset($success)){
						echo '<label>'.$success.'</label>';
					}
				?>
				<div class="form-group">
					<select class="form-control" name="origin2" disabled>
						<option>Aeropuerto Internacional Comodoro Arturo Medino Benítez</option>
					</select>
				</div>
				<div class="form-group">
					<select class="form-control" name="tviaje">
						<option value="null">Tipo de servicio</option>
						<?php $__currentLoopData = $tposviaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tviaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($tviaje->id); ?>"><?php echo e($tviaje->descripcion); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group">
					<select class="form-control" name="comuna">
						<option value="null">Punto de Origen/Destino</option>
						<?php $__currentLoopData = $comunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($comuna->id); ?>"><?php echo e($comuna->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group">
					<select class="form-control" name="passenger">
						<option value="null">Cantidad de pasajeros</option>
						<?php for($i = 1; $i < 9; $i++): ?>
							<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
						<?php endfor; ?>
					</select>
				</div>
				<div class="form-group">
					 <button type="submit" class="btn btn-primary">Enviar</button> 
					<!--<button type="button" data-toggle="modal" data-target="#create" class="btn btn-primary">Enviar</button>-->
				</div>
			</form>
		</div>
	</div>
</div>
<div class="container-fluid ext register">
	<div class="col-md-6">
		<h3>Registrate</h3>
		<span class="text-light">Para recibir atencion personalizada, noticias y promociones de nuestros servicios.</span>
	</div>
	<div class="col-md-6" id="contactForm">
		<form>
			<div class="col-md-9">
				<input type="text" class="form-control" placeholder="Ingrese su E-mail" name="">
			</div>
			<div class="col-md-3">
				<a href="<?php echo e(route('register')); ?>" class="btn btn-default">Registrate!</a>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php echo $__env->make('transfer.cotizacion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>