<?php $__env->startSection('content'); ?>
<div class="row">
	<section class="content">
		<div class="col-md-8 col-md-offset-2">
			<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>

			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Editar Transfer</h3>
				</div>
				<div class="panel-body">					
					<div class="table-container">
						<form method="POST" action="<?php echo e(route('transfer.cancel', $transfer->id)); ?>"  role="form">
							<?php echo e(csrf_field()); ?>

							<input name="_method" type="hidden" value="PATCH">
							<div class="row">
								<div class="col-xs-12">
									<div class="form-group">
										<h4>Login: <strong><?php echo e($transfer->user->name); ?></strong></h4>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Estado de servicio:</label>
										<select name="status" class="form-control" disabled="disabled">
											<option value="<?php echo e($status->statetf->id); ?>"><?php echo e($status->statetf->valor); ?></option>
											<?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if( $estado->id != $status->statetf->id ): ?>
													<option value="<?php echo e($estado->id); ?>"><?php echo e($estado->valor); ?></option>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
								<input type="hidden" name="id" id="id" class="form-control input-sm" value="<?php echo e($transfer->id); ?>">
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Nombre:</label>
										<input type="text" name="name" id="name" class="form-control input-sm" value="<?php echo e($transfer->name); ?>" disabled="disabled">
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Email:</label>
										<input type="email" name="email" id="email" class="form-control input-sm" value="<?php echo e($transfer->email); ?>" disabled="disabled">
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Fecha:</label>
										<input type="date" name="date" class="form-control input-sm" value="<?php echo e($transfer->date_pick); ?>" min="<?php echo e($transfer->date_pick); ?>" disabled="disabled">
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Hora:</label>
										<input type="time" name="time" class="form-control input-sm" value="<?php echo e($transfer->time_pick); ?>" disabled="disabled">
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Tipo de servicio:</label>
										<select name="tviaje" class="form-control" disabled="disabled">
											<option value="<?php echo e($transfer->precio->tviaje->id); ?>"><?php echo e($transfer->precio->tviaje->descripcion); ?></option>
											<?php $__currentLoopData = $tviajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tviaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if( $tviaje->id != $transfer->precio->tviaje->id ): ?>
													<option value="<?php echo e($tviaje->id); ?>"><?php echo e($tviaje->descripcion); ?></option>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Vehículo:</label>
										<select name="vehicle" class="form-control" disabled="disabled">
											<option value="<?php echo e($transfer->vehicle->id); ?>"><?php echo e($transfer->vehicle->description); ?></option>
											<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if( $vehicle != $transfer->vehicle ): ?>
											<option value="<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->description); ?></option>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Comuna:</label>
										<select name="comuna" class="form-control" disabled="disabled">
											<option value="<?php echo e($transfer->precio->comuna->id); ?>"><?php echo e($transfer->precio->comuna->name); ?></option>
											<?php $__currentLoopData = $comunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if( $comuna != $transfer->precio->comuna ): ?>
											<option value="<?php echo e($comuna->id); ?>"><?php echo e($comuna->name); ?></option>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Precio:</label>
										<input type="text" name="price" class="form-control input-sm" value="<?php echo e($transfer->precio->precio); ?>" disabled="disabled">
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Cantidad de pasajeros:</label>
										<input type="text" name="passenger" class="form-control input-sm" value="<?php echo e($transfer->passengers); ?>" disabled="disabled">
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<label class="col-md-6">Cantidad de maletas:</label>
										<input type="text" name="suitcase" class="form-control input-sm" value="<?php echo e($transfer->suitcase); ?>" disabled="disabled">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-12">
									<?php if($transfer->user->role_id == 1): ?>
										<button class="btn btn-success" type="submit">Guardar</button>
										<a href="<?php echo e(route('transfer.index')); ?>" class="btn btn-info" >Atrás</a>
									<?php else: ?>
										
										<?php if($status->statetf_id != 4): ?>
											<button class="btn btn-danger" type="submit">Cancelar Servicio</button>
										<?php endif; ?>
										<a href="<?php echo e(action('TransferController@indexu', Auth::user()->id)); ?>" class="btn btn-info" >Atrás</a>
									<?php endif; ?>
								</div>	
							</div>
						</form>
					</div>
				</div>

			</div>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>