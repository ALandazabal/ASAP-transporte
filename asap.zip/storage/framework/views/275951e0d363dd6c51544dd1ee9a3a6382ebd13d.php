<?php $__env->startSection('content'); ?>
<div class="row">
	<section class="content">
		<div class="col-md-8 col-md-offset-2">
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="pull-left"><h3>Lista de Comunas</h3></div>
					<div class="pull-right">
						<div class="btn-group">
							<a href="<?php echo e(route('comuna.create')); ?>" class="btn btn-info" >Añadir Comuna</a>
						</div>
					</div>
					<div class="table-container">
						<table id="mytable" class="table table-bordred table-striped">
							<thead>
								<th>#</th>
								<th>Nombre</th>
								<th>Distancia</th>
								<th>Coordenadas</th>
								
								<th>Eliminar</th>
							</thead>
							<tbody>
								<?php if($comunas->isNotEmpty()): ?>
									<?php $__currentLoopData = $comunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
										<tr>
											<td><?php echo e($loop->iteration); ?></td>
											<td><?php echo e($comuna->name); ?></td>
											<td><?php echo e($comuna->distance); ?></td>
											<td><?php echo e($comuna->coords); ?></td>
											
											<td>
												<form action="<?php echo e(action('ComunaController@destroy', $comuna->id)); ?>" method="post">
												<?php echo e(csrf_field()); ?>

												<input name="_method" type="hidden" value="DELETE">

												<button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span></button>
												</form>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
								<?php else: ?>
								<tr>
									<td colspan="8">No hay registro !!</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>