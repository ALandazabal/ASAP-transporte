<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="col-md-4 col-md-offset-4 text-center">
		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Error!</strong> Revise los campos obligatorios.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">Editar Comuna</h3>
			</div>
			<div class="panel-body">
				<div class="table-container">
					<form method="post" action="<?php echo e(route('comuna.update', $comuna->id)); ?>" role="form">
						<?php echo e(csrf_field()); ?>

						<input name="_method" type="hidden" value="PATCH">
						<label for="Name">Nombre</label>
						<input type="text" class="form-control" name="name" value="<?php echo e($comuna->name); ?>">
						<label for="Distance">Distancia</label>
						<input type="number" step=0.01 class="form-control" name="distance" value="<?php echo e($comuna->distance); ?>">
						<label for="Coords">Coordenadas</label>
						<input type="text" class="form-control" name="coords" value="<?php echo e($comuna->coords); ?>">
						<button type="submit" class="btn btn-success">Agregar</button>
						<a href="<?php echo e(route('comuna.index')); ?>" class="btn btn-info" >Atrás</a>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>