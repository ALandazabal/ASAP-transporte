<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="col-md-4 col-md-offset-4 text-center">
		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Error!</strong> Revise los campos obligatorios.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">Nueva Comuna</h3>
			</div>
			<div class="panel-body">
				<div class="table-container">
					<form method="post" action="<?php echo e(route('comuna.store')); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<label for="Name">Nombre</label>
						<input type="text" class="form-control" name="name">
						<label for="Description">Descripción</label>
						<input type="text" class="form-control" name="description">
						<label for="tposviajei">Tipo de viaje</label>
						<select class="form-control" name="tposviajei">
							<?php $__currentLoopData = $tposviajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tposviaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($tposviaje->id); ?>"><?php echo e($tposviaje->descripcion); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<label for="Price">Precio</label>
						<input type="text" class="form-control" name="precio">
						<label for="Distance">Distancia</label>
						<input type="number" step=0.01 class="form-control" name="distance">
						<label for="Coords">Coordenadas</label>
						<input type="text" class="form-control" name="coords">
						<button type="submit" class="btn btn-success">Agregar</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>