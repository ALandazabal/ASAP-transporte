<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-md-4 col-md-push-4 text-center">
		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Error!</strong> Revise los campos obligatorios.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(Session::has('success')): ?>
		<div class="alert alert-info">
			<?php echo e(Session::get('success')); ?>

		</div>
		<?php endif; ?>

		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">Nuevo Usuario</h3>
			</div>
			<div class="panel-body">					
				<div class="table-container">
					<form method="POST" action="<?php echo e(route('users.store')); ?>"  role="form">
						<?php echo e(csrf_field()); ?>

						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<input type="text" name="name" id="name" class="form-control input-sm" placeholder="Nombre del usuario">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<input type="email" name="email" id="email" class="form-control input-sm" placeholder="E-mail del usuario">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<input type="password" name="password" id="password" class="form-control input-sm" placeholder="Contraseña del usuario">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<select class="form-control" name="role">
										<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<button class="btn btn-success" type="submit">Guardar</button>
								<a href="<?php echo e(route('users.index')); ?>" class="btn btn-info" >Atrás</a>
							</div>	
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>