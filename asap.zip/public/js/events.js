$(document).ready( function(){
	$("#app-navbar-collapse .navbar-right").togle();
});